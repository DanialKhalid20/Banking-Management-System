create table manager(
bankid int primary key,
password varchar(50)
);


create table om(
bankid int primary key,
cnic varchar(13) unique,
password varchar(50)
);

create table om1(
name varchar(50),
fathername varchar(50),
cnic varchar(13) foreign key references om(cnic),
age int,
address varchar(100),
constraint pk primary key(cnic)
);

create table acc(
bankid int primary key,
cnic varchar(13) unique,
password varchar(50)

);

create table acc1(
name varchar(50),
fathername varchar(50),
cnic varchar(13) foreign key references acc(cnic),
age int,
address varchar(100),
constraint pk1 primary key(cnic)
);

create table customer(
accno int primary key,
bal int,
cnic varchar(13) unique,
);

create table customer1(
name varchar(50),
fathername varchar(50),
cnic varchar(13) foreign key references customer(cnic),
age int,
address varchar(100),
constraint pk2 primary key(cnic),
occupation varchar(50),
income int
);


insert into customer values (0001,2000,'1234');
insert into customer1 values ('Danial','Khalid','1234',20,'njnjbjb','eded',34);


insert into manager values(0001,'manager');

insert into om values(0001,'6110109876579','omanager');

insert into acc values(0001,'6110175849039','accountant');
delete from acc;
delete from acc1;

insert into acc values (0001,'6110102237203','accountant');
insert into acc1 values ('Danial','Khalid','6110102237203',20,'njnjbjb');

insert into om1 values('musab','mufti','6110109876579',43,'bdhbdh');

delete from om where bankid=2;

Alter table customer1 drop constraint FK__customer1__cnic__35BCFE0A;
Alter table customer1 add constraint fk_cust_cnic_cascade_delete foreign key (cnic) references customer(cnic) on delete cascade;

Alter table om1 drop constraint FK__om1__cnic__29572725;
Alter table om1 add constraint fk_om_cnic_cascade_delete foreign key (cnic) references om(cnic) on delete cascade;