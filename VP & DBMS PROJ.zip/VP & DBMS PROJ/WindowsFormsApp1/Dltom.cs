﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Dltom : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public Dltom()
        {
            InitializeComponent();
        }

        private void Dltom_Load(object sender, EventArgs e)
        {
            bunifuThinButton23.BackColor = Color.Transparent;
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            if (textBox2.Text==null)
            {
                MessageBox.Show("Enter cnic");
            }

            else
            {
                con.Open();


                String query3 = "delete from om where cnic='" + textBox2.Text + "' ";
                SqlDataAdapter sda3 = new SqlDataAdapter(query3, con);
                DataTable dtb3 = new DataTable();
                sda3.Fill(dtb3);





                if (/*dtb1.Rows.Count == 0 && dtb2.Rows.Count == 0 &&*/ dtb3.Rows.Count == 0)
                {
                    textBox2.Clear();
                    MessageBox.Show("DELETED SUCCESSFULLY");
                }
                else
                {
                    textBox2.Clear();
                    MessageBox.Show("Enter relevant string");
                }

                con.Close();

            }
        }
    }
}
