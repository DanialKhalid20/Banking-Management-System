﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class Transactions : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");
        private int y;
        private int z;
        public Transactions()
        {
            InitializeComponent();
        }

        private void Transactions_Load(object sender, EventArgs e)
        {
            bunifuThinButton23.BackColor = Color.Transparent;
            bunifuThinButton22.BackColor = Color.Transparent;
            bunifuThinButton21.BackColor = Color.Transparent;


        }

        public void bunifuGradientPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            
            con.Open();
            string query1 = "select bal from customer where accno='" + int.Parse(textBox5.Text) + "'";
            
            SqlCommand cmd1 = new SqlCommand(query1, con);
            SqlDataReader sd1 = cmd1.ExecuteReader();
            while (sd1.Read())
            {
                y = int.Parse(sd1.GetValue(0).ToString());
            }

            sd1.Close();
            int x = Convert.ToInt32(textBox1.Text);
            if (y < x)
            {
                MessageBox.Show("Error");
            }
            else
            {
                string query = "update customer set bal=bal - @x where accno='" + int.Parse(textBox5.Text) + "'";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("x", x);
                SqlDataReader sd = cmd.ExecuteReader();
                MessageBox.Show("withdrawn");
            }

            con.Close();

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            con.Open();
            int x = Convert.ToInt32(textBox2.Text);
            string query = "update customer set bal=bal + @x where accno='" + int.Parse(textBox3.Text) + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("x", x);
            SqlDataReader sd = cmd.ExecuteReader();
            MessageBox.Show("Deposited");


            con.Close();

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {

            con.Open();
            string query1 = "select bal from customer where accno='" + int.Parse(textBox6.Text) + "'";
            

            SqlCommand cmd1 = new SqlCommand(query1, con);
            SqlDataReader sd1 = cmd1.ExecuteReader();
            while (sd1.Read())
            {
                y = int.Parse(sd1.GetValue(0).ToString());
            }

            sd1.Close();
            int x = Convert.ToInt32(textBox7.Text);
            int z = Convert.ToInt32(textBox7.Text);
            if (y < x)
            {
                MessageBox.Show("Insufficient balance");
            }
         
            else
            {
                string query = "update customer set bal=bal + @x where accno='" + int.Parse(textBox4.Text) + "'";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@x", x);
                SqlDataReader sd = cmd.ExecuteReader();
                sd.Close();
               
                string query2 = "update customer set bal=bal - @z where accno='" + int.Parse(textBox6.Text) + "'";

                SqlCommand cmd2 = new SqlCommand(query2, con);
                cmd2.Parameters.AddWithValue("@z", z);
                SqlDataReader sd2 = cmd2.ExecuteReader();
                MessageBox.Show("Transfer successful");

            }

            con.Close();

        }
    }
}
