﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class chkbal : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");
        public chkbal()
        {
            InitializeComponent();
        }

        private void chkbal_Load(object sender, EventArgs e)
        {
            bunifuThinButton23.BackColor = Color.Transparent;
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {

            con.Open();
            string query1 = "select bal from customer where accno='"+textBox5.Text+"'";

            SqlCommand cmd = new SqlCommand(query1, con);

            SqlDataReader sd = cmd.ExecuteReader();

            while (sd.Read())
            {
                textBox1.Visible=true;
                textBox1.Text= sd.GetValue(0).ToString();


            }





                con.Close();
            
        }
    }
}
