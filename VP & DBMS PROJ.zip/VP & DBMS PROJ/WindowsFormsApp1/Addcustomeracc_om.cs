﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{

    public partial class Addcustomeracc_om : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public Addcustomeracc_om()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into customer(accno,bal,cnic) values('" + textBox7.Text + "','" + textBox9.Text + "','" + textBox2.Text + "')", con);
            SqlCommand cmd1 = new SqlCommand("insert into customer1(name,fathername,cnic,age,address,occupation,income) values('" + textBox4.Text + "','" + textBox5.Text + "','" + textBox2.Text + "','" + textBox1.Text + "','" + textBox3.Text + "','" + textBox6.Text + "','" + textBox8.Text + "')", con);

            int i = cmd.ExecuteNonQuery();
            int z = cmd1.ExecuteNonQuery();
            if (i != 0 && z != 0)
            {
                MessageBox.Show("saved");
                textBox1.Clear();
                textBox6.Clear();
                textBox2.Clear();
                textBox8.Clear();
                textBox4.Clear();
                textBox3.Clear();
                textBox5.Clear();
                textBox7.Clear();
                textBox9.Clear();
            }
            else
            {
                MessageBox.Show("error");
            }


            con.Close();
        


    }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Addcustomeracc_om_Load(object sender, EventArgs e)
        {
            bunifuThinButton21.BackColor = Color.Transparent;
        }
    }
}
