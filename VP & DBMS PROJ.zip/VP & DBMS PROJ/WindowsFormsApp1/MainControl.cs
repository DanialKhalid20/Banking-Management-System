﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.conrol;
namespace WindowsFormsApp1
{
    class MainControl
    {

        public void showControl(Control control)
        {

            control.Dock = DockStyle.Fill;
            control.BringToFront();
            control.Focus();

            
        }
    }
}
