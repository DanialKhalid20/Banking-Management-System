﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Addacc : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");
        public Addacc()
        {
            InitializeComponent();
        }

        private void Addacc_Load(object sender, EventArgs e)
        {
            bunifuThinButton21.BackColor = Color.Transparent;




        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into acc(bankid,cnic,password) values('" + textBox6.Text + "','" + textBox2.Text + "','" + textBox8.Text + "')", con);
            SqlCommand cmd1 = new SqlCommand("insert into acc1(name,fathername,cnic,age,address) values('" + textBox4.Text + "','" + textBox5.Text + "','" + textBox2.Text + "','" + textBox1.Text + "','" + textBox3.Text + "')", con);

            int i = cmd.ExecuteNonQuery();
            int z = cmd1.ExecuteNonQuery();
            if (i != 0 && z != 0)
            {
                MessageBox.Show("saved");
                textBox1.Clear();
                textBox6.Clear();
                textBox2.Clear();
                textBox8.Clear();
                textBox4.Clear();
                textBox3.Clear();
                textBox5.Clear();
            }
            else
            {
                MessageBox.Show("error");
            }


            con.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)){
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (Char.IsDigit(ch)) {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }
    }
}
