﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ManageAccountants : Form
    {
        public ManageAccountants()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            Addaccountant d1 = new Addaccountant();
            this.Hide();
            d1.Show();

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            Deleteaccountant d = new Deleteaccountant();
            this.Hide();
            d.Show();
        }
    }
}
