﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class manager : Form
    {
        public manager()
        {
            InitializeComponent();
        }

      

        private void timer1_Tick(object sender, EventArgs e)
        {
            label5.Text = DateTime.Now.ToLongTimeString();
            label4.Text = DateTime.Now.ToLongDateString();
        }

        private void guna2PictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btmax_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btmax.Visible = false;
            restoredown.Location = btmax.Location;
            restoredown.Visible=true;

             
        }

        private void restoredown_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            restoredown.Visible = false;
            btmax.Visible = true;

        }

        private void guna2PictureBox5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2PictureBox3_Click(object sender, EventArgs e)
        {
           
            
        }
        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void guna2PictureBox2_Click(object sender, EventArgs e)
        {
            
        }
       

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuThinButton27_Click(object sender, EventArgs e)
        {
            updatecustacc1.Visible = true;
            updatecustacc1.BringToFront();
        }

        private void manager_Load(object sender, EventArgs e)
        {
            bunifuThinButton27.BackColor = Color.Transparent;
            bunifuThinButton21.BackColor = Color.Transparent;
            bunifuThinButton28.BackColor = Color.Transparent;
            bunifuThinButton22.BackColor = Color.Transparent; 
            bunifuThinButton29.BackColor = Color.Transparent;
            bunifuThinButton210.BackColor = Color.Transparent;
            bunifuThinButton212.BackColor = Color.Transparent;
            bunifuThinButton213.BackColor = Color.Transparent;
            bunifuThinButton214.BackColor = Color.Transparent;
            bunifuThinButton23.BackColor = Color.Transparent;
            bunifuThinButton24.BackColor = Color.Transparent;
            bunifuThinButton25.BackColor = Color.Transparent;
            bunifuThinButton26.BackColor = Color.Transparent;
            bunifuThinButton215.BackColor = Color.Transparent;
            bunifuThinButton216.BackColor = Color.Transparent;

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            deletecustAcc1.Visible = true;
            deletecustAcc1.BringToFront();
            

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            addcustomeracc_om1.Visible = true;
            addcustomeracc_om1.BringToFront();
        }

        private void bunifuThinButton216_Click(object sender, EventArgs e)
        {
            transactions1.Visible = true;
            transactions1.BringToFront();
        }

        private void bunifuThinButton28_Click(object sender, EventArgs e)
        {
            chkbal1.Visible = true;
            chkbal1.BringToFront();
        }

        private void bunifuThinButton213_Click(object sender, EventArgs e)
        {
            dltom1.Visible = true;
            dltom1.BringToFront();
        }

        private void bunifuThinButton214_Click(object sender, EventArgs e)
        {
            addom1.Visible = true;
            addom1.BringToFront();
        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            dltacc1.Visible = true;
            dltacc1.BringToFront();
        }

        private void bunifuThinButton28_Click_1(object sender, EventArgs e)
        {
            chkbal1.Visible = true;
            chkbal1.BringToFront();
        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
            addacc1.Visible = true;
            addacc1.BringToFront();
        }

        private void bunifuThinButton29_Click(object sender, EventArgs e)
        {
            showcustdetails1.Visible = true;
            showcustdetails1.BringToFront();
        }

        private void bunifuThinButton212_Click(object sender, EventArgs e)
        {
            updateom1.Visible = true;
            updateom1.BringToFront();
        }

        private void bunifuThinButton210_Click(object sender, EventArgs e)
        {
            showom1.Visible = true;
            showom1.BringToFront();
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            updateacc1.Visible = true;
            updateacc1.BringToFront();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
           
        }

        private void updatecustacc1_Load(object sender, EventArgs e)
        {

        }

        private void addom1_Load(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton215_Click(object sender, EventArgs e)
        {
            this.Hide();
            signin s = new signin();
            s.Show();
            
        }

        private void bunifuThinButton23_Click_1(object sender, EventArgs e)
        {
            
        }

        private void showacc1_Load(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton23_Click_2(object sender, EventArgs e)
        {
            showacc1.Visible = true;
            showacc1.BringToFront();

        }
    }
}
