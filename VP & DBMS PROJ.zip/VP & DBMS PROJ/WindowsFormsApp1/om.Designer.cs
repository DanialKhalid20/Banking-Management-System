﻿
namespace WindowsFormsApp1
{
    partial class om
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(om));
            this.bunifuThinButton215 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton23 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton24 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton25 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton26 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuGradientPanel3 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.restoredown = new Guna.UI2.WinForms.Guna2PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuGradientPanel2 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuThinButton216 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton29 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton28 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton27 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.Manage = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.btmax = new Guna.UI2.WinForms.Guna2PictureBox();
            this.deletecustAcc1 = new WindowsFormsApp1.DeletecustAcc();
            this.addacc1 = new WindowsFormsApp1.Addacc();
            this.addcustomeracc_om1 = new WindowsFormsApp1.Addcustomeracc_om();
            this.chkbal1 = new WindowsFormsApp1.chkbal();
            this.updateacc1 = new WindowsFormsApp1.Updateacc();
            this.updatecustacc1 = new WindowsFormsApp1.Updatecustacc();
            this.showacc1 = new WindowsFormsApp1.Showacc();
            this.showcustdetails1 = new WindowsFormsApp1.showcustdetails();
            this.transactions1 = new WindowsFormsApp1.Transactions();
            this.dltacc1 = new WindowsFormsApp1.Dltacc();
            this.bunifuGradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.restoredown)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            this.bunifuGradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btmax)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuThinButton215
            // 
            this.bunifuThinButton215.ActiveBorderThickness = 1;
            this.bunifuThinButton215.ActiveCornerRadius = 20;
            this.bunifuThinButton215.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton215.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton215.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton215.BackgroundImage")));
            this.bunifuThinButton215.ButtonText = "LOGOUT";
            this.bunifuThinButton215.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton215.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton215.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.IdleBorderThickness = 1;
            this.bunifuThinButton215.IdleCornerRadius = 20;
            this.bunifuThinButton215.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton215.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.Location = new System.Drawing.Point(81, 664);
            this.bunifuThinButton215.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton215.Name = "bunifuThinButton215";
            this.bunifuThinButton215.Size = new System.Drawing.Size(193, 56);
            this.bunifuThinButton215.TabIndex = 19;
            this.bunifuThinButton215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton215.Click += new System.EventHandler(this.bunifuThinButton215_Click);
            // 
            // bunifuThinButton23
            // 
            this.bunifuThinButton23.ActiveBorderThickness = 1;
            this.bunifuThinButton23.ActiveCornerRadius = 20;
            this.bunifuThinButton23.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton23.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton23.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton23.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton23.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton23.BackgroundImage")));
            this.bunifuThinButton23.ButtonText = "Show All Accounts";
            this.bunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton23.Font = new System.Drawing.Font("Microsoft YaHei UI", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton23.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton23.IdleBorderThickness = 1;
            this.bunifuThinButton23.IdleCornerRadius = 20;
            this.bunifuThinButton23.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton23.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton23.IdleLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton23.Location = new System.Drawing.Point(161, 49);
            this.bunifuThinButton23.Name = "bunifuThinButton23";
            this.bunifuThinButton23.Size = new System.Drawing.Size(153, 45);
            this.bunifuThinButton23.TabIndex = 15;
            this.bunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton23.Click += new System.EventHandler(this.bunifuThinButton23_Click);
            // 
            // bunifuThinButton24
            // 
            this.bunifuThinButton24.ActiveBorderThickness = 1;
            this.bunifuThinButton24.ActiveCornerRadius = 20;
            this.bunifuThinButton24.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton24.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton24.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton24.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton24.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton24.BackgroundImage")));
            this.bunifuThinButton24.ButtonText = "Update Account";
            this.bunifuThinButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton24.Font = new System.Drawing.Font("Microsoft YaHei UI", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton24.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton24.IdleBorderThickness = 1;
            this.bunifuThinButton24.IdleCornerRadius = 20;
            this.bunifuThinButton24.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton24.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton24.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton24.Location = new System.Drawing.Point(3, 49);
            this.bunifuThinButton24.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuThinButton24.Name = "bunifuThinButton24";
            this.bunifuThinButton24.Size = new System.Drawing.Size(152, 45);
            this.bunifuThinButton24.TabIndex = 13;
            this.bunifuThinButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton24.Click += new System.EventHandler(this.bunifuThinButton24_Click);
            // 
            // bunifuThinButton25
            // 
            this.bunifuThinButton25.ActiveBorderThickness = 1;
            this.bunifuThinButton25.ActiveCornerRadius = 20;
            this.bunifuThinButton25.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton25.ActiveForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton25.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton25.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton25.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton25.BackgroundImage")));
            this.bunifuThinButton25.ButtonText = "Delete Account";
            this.bunifuThinButton25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton25.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton25.ForeColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton25.IdleBorderThickness = 1;
            this.bunifuThinButton25.IdleCornerRadius = 20;
            this.bunifuThinButton25.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton25.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton25.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton25.Location = new System.Drawing.Point(3, 4);
            this.bunifuThinButton25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuThinButton25.Name = "bunifuThinButton25";
            this.bunifuThinButton25.Size = new System.Drawing.Size(152, 44);
            this.bunifuThinButton25.TabIndex = 11;
            this.bunifuThinButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton25.Click += new System.EventHandler(this.bunifuThinButton25_Click);
            // 
            // bunifuThinButton26
            // 
            this.bunifuThinButton26.ActiveBorderThickness = 1;
            this.bunifuThinButton26.ActiveCornerRadius = 20;
            this.bunifuThinButton26.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton26.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton26.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton26.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton26.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton26.BackgroundImage")));
            this.bunifuThinButton26.ButtonText = "Add Account";
            this.bunifuThinButton26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton26.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton26.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton26.IdleBorderThickness = 1;
            this.bunifuThinButton26.IdleCornerRadius = 20;
            this.bunifuThinButton26.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton26.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton26.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton26.Location = new System.Drawing.Point(161, 4);
            this.bunifuThinButton26.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuThinButton26.Name = "bunifuThinButton26";
            this.bunifuThinButton26.Size = new System.Drawing.Size(152, 45);
            this.bunifuThinButton26.TabIndex = 10;
            this.bunifuThinButton26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton26.Click += new System.EventHandler(this.bunifuThinButton26_Click);
            // 
            // bunifuGradientPanel3
            // 
            this.bunifuGradientPanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel3.BackgroundImage")));
            this.bunifuGradientPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton23);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton24);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton25);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton26);
            this.bunifuGradientPanel3.GradientBottomLeft = System.Drawing.Color.SeaGreen;
            this.bunifuGradientPanel3.GradientBottomRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel3.GradientTopLeft = System.Drawing.Color.DarkGreen;
            this.bunifuGradientPanel3.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel3.Location = new System.Drawing.Point(15, 401);
            this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
            this.bunifuGradientPanel3.Quality = 10;
            this.bunifuGradientPanel3.Size = new System.Drawing.Size(317, 102);
            this.bunifuGradientPanel3.TabIndex = 17;
            // 
            // restoredown
            // 
            this.restoredown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.restoredown.BackColor = System.Drawing.Color.Transparent;
            this.restoredown.FillColor = System.Drawing.Color.Transparent;
            this.restoredown.Image = ((System.Drawing.Image)(resources.GetObject("restoredown.Image")));
            this.restoredown.ImageRotate = 0F;
            this.restoredown.Location = new System.Drawing.Point(987, 10);
            this.restoredown.Name = "restoredown";
            this.restoredown.Size = new System.Drawing.Size(22, 23);
            this.restoredown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.restoredown.TabIndex = 18;
            this.restoredown.TabStop = false;
            this.restoredown.Visible = false;
            this.restoredown.Click += new System.EventHandler(this.restoredown_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuThinButton215);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuGradientPanel3);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuGradientPanel2);
            this.bunifuGradientPanel1.Controls.Add(this.label4);
            this.bunifuGradientPanel1.Controls.Add(this.label5);
            this.bunifuGradientPanel1.Controls.Add(this.label3);
            this.bunifuGradientPanel1.Controls.Add(this.guna2PictureBox3);
            this.bunifuGradientPanel1.Controls.Add(this.Manage);
            this.bunifuGradientPanel1.Controls.Add(this.guna2PictureBox1);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.SeaGreen;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.LightSeaGreen;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.Green;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Teal;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(345, 743);
            this.bunifuGradientPanel1.TabIndex = 13;
            // 
            // bunifuGradientPanel2
            // 
            this.bunifuGradientPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel2.BackgroundImage")));
            this.bunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton216);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton29);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton28);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton27);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton22);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton21);
            this.bunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.SeaGreen;
            this.bunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.DarkGreen;
            this.bunifuGradientPanel2.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel2.Location = new System.Drawing.Point(12, 162);
            this.bunifuGradientPanel2.Name = "bunifuGradientPanel2";
            this.bunifuGradientPanel2.Quality = 10;
            this.bunifuGradientPanel2.Size = new System.Drawing.Size(317, 144);
            this.bunifuGradientPanel2.TabIndex = 13;
            // 
            // bunifuThinButton216
            // 
            this.bunifuThinButton216.ActiveBorderThickness = 1;
            this.bunifuThinButton216.ActiveCornerRadius = 20;
            this.bunifuThinButton216.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton216.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton216.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton216.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton216.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton216.BackgroundImage")));
            this.bunifuThinButton216.ButtonText = "Transactions";
            this.bunifuThinButton216.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton216.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton216.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.IdleBorderThickness = 1;
            this.bunifuThinButton216.IdleCornerRadius = 20;
            this.bunifuThinButton216.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton216.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton216.Location = new System.Drawing.Point(161, 94);
            this.bunifuThinButton216.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuThinButton216.Name = "bunifuThinButton216";
            this.bunifuThinButton216.Size = new System.Drawing.Size(152, 46);
            this.bunifuThinButton216.TabIndex = 25;
            this.bunifuThinButton216.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton216.Click += new System.EventHandler(this.bunifuThinButton216_Click);
            // 
            // bunifuThinButton29
            // 
            this.bunifuThinButton29.ActiveBorderThickness = 1;
            this.bunifuThinButton29.ActiveCornerRadius = 20;
            this.bunifuThinButton29.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton29.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton29.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton29.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton29.BackgroundImage")));
            this.bunifuThinButton29.ButtonText = "Show All Accounts";
            this.bunifuThinButton29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton29.Font = new System.Drawing.Font("Microsoft YaHei UI", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton29.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton29.IdleBorderThickness = 1;
            this.bunifuThinButton29.IdleCornerRadius = 20;
            this.bunifuThinButton29.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton29.IdleLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.Location = new System.Drawing.Point(3, 95);
            this.bunifuThinButton29.Name = "bunifuThinButton29";
            this.bunifuThinButton29.Size = new System.Drawing.Size(152, 45);
            this.bunifuThinButton29.TabIndex = 15;
            this.bunifuThinButton29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton29.Click += new System.EventHandler(this.bunifuThinButton29_Click);
            // 
            // bunifuThinButton28
            // 
            this.bunifuThinButton28.ActiveBorderThickness = 1;
            this.bunifuThinButton28.ActiveCornerRadius = 20;
            this.bunifuThinButton28.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton28.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton28.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton28.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton28.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton28.BackgroundImage")));
            this.bunifuThinButton28.ButtonText = "Check Balance";
            this.bunifuThinButton28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton28.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton28.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton28.IdleBorderThickness = 1;
            this.bunifuThinButton28.IdleCornerRadius = 20;
            this.bunifuThinButton28.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton28.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton28.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton28.Location = new System.Drawing.Point(162, 50);
            this.bunifuThinButton28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuThinButton28.Name = "bunifuThinButton28";
            this.bunifuThinButton28.Size = new System.Drawing.Size(152, 45);
            this.bunifuThinButton28.TabIndex = 14;
            this.bunifuThinButton28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton28.Click += new System.EventHandler(this.bunifuThinButton28_Click);
            // 
            // bunifuThinButton27
            // 
            this.bunifuThinButton27.ActiveBorderThickness = 1;
            this.bunifuThinButton27.ActiveCornerRadius = 20;
            this.bunifuThinButton27.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton27.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton27.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton27.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton27.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton27.BackgroundImage")));
            this.bunifuThinButton27.ButtonText = "Update Account";
            this.bunifuThinButton27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton27.Font = new System.Drawing.Font("Microsoft YaHei UI", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton27.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton27.IdleBorderThickness = 1;
            this.bunifuThinButton27.IdleCornerRadius = 20;
            this.bunifuThinButton27.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton27.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton27.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton27.Location = new System.Drawing.Point(3, 49);
            this.bunifuThinButton27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuThinButton27.Name = "bunifuThinButton27";
            this.bunifuThinButton27.Size = new System.Drawing.Size(152, 45);
            this.bunifuThinButton27.TabIndex = 13;
            this.bunifuThinButton27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton27.Click += new System.EventHandler(this.bunifuThinButton27_Click);
            // 
            // bunifuThinButton22
            // 
            this.bunifuThinButton22.ActiveBorderThickness = 1;
            this.bunifuThinButton22.ActiveCornerRadius = 20;
            this.bunifuThinButton22.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton22.ActiveForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton22.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton22.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton22.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton22.BackgroundImage")));
            this.bunifuThinButton22.ButtonText = "Delete Account";
            this.bunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton22.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton22.ForeColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton22.IdleBorderThickness = 1;
            this.bunifuThinButton22.IdleCornerRadius = 20;
            this.bunifuThinButton22.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton22.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton22.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton22.Location = new System.Drawing.Point(3, 4);
            this.bunifuThinButton22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuThinButton22.Name = "bunifuThinButton22";
            this.bunifuThinButton22.Size = new System.Drawing.Size(152, 44);
            this.bunifuThinButton22.TabIndex = 11;
            this.bunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton22.Click += new System.EventHandler(this.bunifuThinButton22_Click);
            // 
            // bunifuThinButton21
            // 
            this.bunifuThinButton21.ActiveBorderThickness = 1;
            this.bunifuThinButton21.ActiveCornerRadius = 20;
            this.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton21.BackColor = System.Drawing.Color.Black;
            this.bunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton21.BackgroundImage")));
            this.bunifuThinButton21.ButtonText = "Add Account";
            this.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton21.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton21.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton21.IdleBorderThickness = 1;
            this.bunifuThinButton21.IdleCornerRadius = 20;
            this.bunifuThinButton21.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton21.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton21.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.Location = new System.Drawing.Point(161, 4);
            this.bunifuThinButton21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuThinButton21.Name = "bunifuThinButton21";
            this.bunifuThinButton21.Size = new System.Drawing.Size(152, 45);
            this.bunifuThinButton21.TabIndex = 10;
            this.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton21.Click += new System.EventHandler(this.bunifuThinButton21_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(47, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 27);
            this.label4.TabIndex = 1;
            this.label4.Text = "Main Menu";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(58, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(203, 42);
            this.label5.TabIndex = 2;
            this.label5.Text = "Main Menu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(57, 365);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 21);
            this.label3.TabIndex = 7;
            this.label3.Text = "Manage Accountants";
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.ImageRotate = 0F;
            this.guna2PictureBox3.Location = new System.Drawing.Point(12, 111);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.Size = new System.Drawing.Size(40, 40);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 6;
            this.guna2PictureBox3.TabStop = false;
            // 
            // Manage
            // 
            this.Manage.AutoSize = true;
            this.Manage.BackColor = System.Drawing.Color.Transparent;
            this.Manage.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Manage.Location = new System.Drawing.Point(57, 130);
            this.Manage.Name = "Manage";
            this.Manage.Size = new System.Drawing.Size(159, 21);
            this.Manage.TabIndex = 4;
            this.Manage.Text = "Manage Customers";
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(12, 346);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(40, 40);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 1;
            this.guna2PictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SeaGreen;
            this.label1.Location = new System.Drawing.Point(616, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 42);
            this.label1.TabIndex = 14;
            this.label1.Text = "Main Menu";
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2PictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox5.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox5.Image")));
            this.guna2PictureBox5.ImageRotate = 0F;
            this.guna2PictureBox5.Location = new System.Drawing.Point(1015, 9);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.Size = new System.Drawing.Size(22, 23);
            this.guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox5.TabIndex = 16;
            this.guna2PictureBox5.TabStop = false;
            this.guna2PictureBox5.Click += new System.EventHandler(this.guna2PictureBox5_Click);
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2PictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox4.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox4.Image")));
            this.guna2PictureBox4.ImageRotate = 0F;
            this.guna2PictureBox4.Location = new System.Drawing.Point(1072, 9);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.Size = new System.Drawing.Size(22, 23);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox4.TabIndex = 15;
            this.guna2PictureBox4.TabStop = false;
            this.guna2PictureBox4.Click += new System.EventHandler(this.guna2PictureBox4_Click);
            // 
            // btmax
            // 
            this.btmax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btmax.BackColor = System.Drawing.Color.Transparent;
            this.btmax.FillColor = System.Drawing.Color.Transparent;
            this.btmax.Image = ((System.Drawing.Image)(resources.GetObject("btmax.Image")));
            this.btmax.ImageRotate = 0F;
            this.btmax.Location = new System.Drawing.Point(1044, 9);
            this.btmax.Name = "btmax";
            this.btmax.Size = new System.Drawing.Size(22, 23);
            this.btmax.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btmax.TabIndex = 17;
            this.btmax.TabStop = false;
            this.btmax.Click += new System.EventHandler(this.btmax_Click);
            // 
            // deletecustAcc1
            // 
            this.deletecustAcc1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.deletecustAcc1.Location = new System.Drawing.Point(345, 60);
            this.deletecustAcc1.Name = "deletecustAcc1";
            this.deletecustAcc1.Size = new System.Drawing.Size(750, 683);
            this.deletecustAcc1.TabIndex = 19;
            this.deletecustAcc1.Visible = false;
            // 
            // addacc1
            // 
            this.addacc1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.addacc1.Location = new System.Drawing.Point(345, 60);
            this.addacc1.Name = "addacc1";
            this.addacc1.Size = new System.Drawing.Size(750, 683);
            this.addacc1.TabIndex = 20;
            this.addacc1.Visible = false;
            // 
            // addcustomeracc_om1
            // 
            this.addcustomeracc_om1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.addcustomeracc_om1.Location = new System.Drawing.Point(345, 60);
            this.addcustomeracc_om1.Name = "addcustomeracc_om1";
            this.addcustomeracc_om1.Size = new System.Drawing.Size(750, 683);
            this.addcustomeracc_om1.TabIndex = 21;
            this.addcustomeracc_om1.Visible = false;
            // 
            // chkbal1
            // 
            this.chkbal1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkbal1.Location = new System.Drawing.Point(345, 60);
            this.chkbal1.Name = "chkbal1";
            this.chkbal1.Size = new System.Drawing.Size(750, 683);
            this.chkbal1.TabIndex = 22;
            this.chkbal1.Visible = false;
            // 
            // updateacc1
            // 
            this.updateacc1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.updateacc1.Location = new System.Drawing.Point(345, 60);
            this.updateacc1.Name = "updateacc1";
            this.updateacc1.Size = new System.Drawing.Size(750, 683);
            this.updateacc1.TabIndex = 23;
            this.updateacc1.Visible = false;
            // 
            // updatecustacc1
            // 
            this.updatecustacc1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.updatecustacc1.Location = new System.Drawing.Point(345, 60);
            this.updatecustacc1.Name = "updatecustacc1";
            this.updatecustacc1.Size = new System.Drawing.Size(750, 683);
            this.updatecustacc1.TabIndex = 24;
            this.updatecustacc1.Visible = false;
            // 
            // showacc1
            // 
            this.showacc1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.showacc1.Location = new System.Drawing.Point(345, 60);
            this.showacc1.Name = "showacc1";
            this.showacc1.Size = new System.Drawing.Size(750, 686);
            this.showacc1.TabIndex = 25;
            this.showacc1.Visible = false;
            // 
            // showcustdetails1
            // 
            this.showcustdetails1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.showcustdetails1.Location = new System.Drawing.Point(345, 60);
            this.showcustdetails1.Name = "showcustdetails1";
            this.showcustdetails1.Size = new System.Drawing.Size(750, 683);
            this.showcustdetails1.TabIndex = 26;
            this.showcustdetails1.Visible = false;
            // 
            // transactions1
            // 
            this.transactions1.BackColor = System.Drawing.Color.SeaGreen;
            this.transactions1.Location = new System.Drawing.Point(345, 60);
            this.transactions1.Name = "transactions1";
            this.transactions1.Size = new System.Drawing.Size(750, 683);
            this.transactions1.TabIndex = 27;
            this.transactions1.Visible = false;
            // 
            // dltacc1
            // 
            this.dltacc1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dltacc1.Location = new System.Drawing.Point(345, 60);
            this.dltacc1.Name = "dltacc1";
            this.dltacc1.Size = new System.Drawing.Size(750, 683);
            this.dltacc1.TabIndex = 28;
            this.dltacc1.Visible = false;
            // 
            // om
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1095, 743);
            this.Controls.Add(this.restoredown);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guna2PictureBox5);
            this.Controls.Add(this.guna2PictureBox4);
            this.Controls.Add(this.btmax);
            this.Controls.Add(this.transactions1);
            this.Controls.Add(this.showcustdetails1);
            this.Controls.Add(this.showacc1);
            this.Controls.Add(this.chkbal1);
            this.Controls.Add(this.addcustomeracc_om1);
            this.Controls.Add(this.addacc1);
            this.Controls.Add(this.deletecustAcc1);
            this.Controls.Add(this.updatecustacc1);
            this.Controls.Add(this.updateacc1);
            this.Controls.Add(this.dltacc1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "om";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "om";
            this.Load += new System.EventHandler(this.om_Load);
            this.bunifuGradientPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.restoredown)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.bunifuGradientPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btmax)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton215;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton23;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton24;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton25;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton26;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel3;
        private Guna.UI2.WinForms.Guna2PictureBox restoredown;
        private System.Windows.Forms.Timer timer1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel2;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton29;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton28;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton27;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton22;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton21;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private System.Windows.Forms.Label Manage;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2PictureBox btmax;
        private DeletecustAcc deletecustAcc1;
        private Addacc addacc1;
        private Addcustomeracc_om addcustomeracc_om1;
        private chkbal chkbal1;
        private Updateacc updateacc1;
        private Updatecustacc updatecustacc1;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton216;
        private Showacc showacc1;
        private showcustdetails showcustdetails1;
        private Transactions transactions1;
        private Dltacc dltacc1;
    }
}