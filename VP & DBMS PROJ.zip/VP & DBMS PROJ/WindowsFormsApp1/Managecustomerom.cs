﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Managecustomerom : Form
    {
        public Managecustomerom()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            Addaccountant a = new Addaccountant();
            this.Hide();
            a.Show();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            Deleteaccountant d = new Deleteaccountant();
            this.Hide();
            d.Show();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            CheckBalance c = new CheckBalance();
            this.Hide();
            c.Show();
        }
    }
}
