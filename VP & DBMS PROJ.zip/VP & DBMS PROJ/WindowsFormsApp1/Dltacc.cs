﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Dltacc : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public Dltacc()
        {
            InitializeComponent();
        }

        private void Dltacc_Load(object sender, EventArgs e)
        {
            bunifuThinButton22.BackColor = Color.Transparent;
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == null)
            {
                MessageBox.Show("Enter cnic");
            }

            con.Open();
         /*   String query1 = "Alter table acc1 drop constraint FK__acc1__cnic__300424B4";
            SqlDataAdapter sda = new SqlDataAdapter(query1, con);
            DataTable dtb1 = new DataTable();
            sda.Fill(dtb1);

            String query2 = "Alter table acc1 add constraint fk_acc_cnic_cascade_delete foreign key (cnic) references acc(cnic) on delete cascade ";
            SqlDataAdapter sda2 = new SqlDataAdapter(query2, con);
            DataTable dtb2 = new DataTable();
            sda2.Fill(dtb2);
         */

            String query3 = "delete from acc where cnic='"+textBox2.Text+"' ";
            SqlDataAdapter sda3 = new SqlDataAdapter(query3, con);
            DataTable dtb3 = new DataTable();
            sda3.Fill(dtb3);


            if (/*dtb1.Rows.Count == 0 && dtb2.Rows.Count == 0 &&*/ dtb3.Rows.Count == 0 )
            {
                textBox2.Clear();
                MessageBox.Show("DELETED SUCCESSFULLY");
            }
            else
            {
                textBox2.Clear();
                MessageBox.Show("Enter relevant string");
            }

            con.Close();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
