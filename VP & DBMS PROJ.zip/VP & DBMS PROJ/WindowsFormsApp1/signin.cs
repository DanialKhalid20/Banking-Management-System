﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class signin : Form
    {


        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public signin()
        {
            Thread t = new Thread(new ThreadStart(startform));
            t.Start();
            Thread.Sleep(3500);
            InitializeComponent();
            t.Abort();
        }
        public void startform()
        {
            Application.Run(new splash());
        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void signin_Load(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
         }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            string query= "select * from manager where bankid = ' " + textBox1.Text.Trim()+"' and password = '" + textBox2.Text.Trim()+"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dtb1 = new DataTable();
            sda.Fill(dtb1);

            string query1 = "select * from om  where bankid = ' " + textBox1.Text.Trim() + "' and password = '" + textBox2.Text.Trim() + "'";
            SqlDataAdapter sda1 = new SqlDataAdapter(query1, con);
            DataTable dtb2 = new DataTable();
            sda1.Fill(dtb2);


            string query3 = "select * from acc where bankid = ' " + textBox1.Text.Trim() + "' and password = '" + textBox2.Text.Trim() + "'";
            SqlDataAdapter sda2 = new SqlDataAdapter(query3, con);
            DataTable dtb3 = new DataTable();
            sda2.Fill(dtb3);


            if (comboBox1.Text=="Manager" &&  dtb1.Rows.Count==1)
            {
                manager m = new manager();
                this.Hide();
                m.Show();
            }

            else if (comboBox1.Text == "Operational Manager" && dtb2.Rows.Count == 1)
            {
                om m = new om();
                this.Hide();
                m.Show();
            }

            else if (comboBox1.Text == "Accountant" && dtb3.Rows.Count == 1)
            {
                acc a = new acc();
                this.Hide();
                a.Show();
            }
            else
            {
                MessageBox.Show("Wrong number");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = false;
            pictureBox1.Location = pictureBox2.Location;
            pictureBox2.Visible = false;
            pictureBox1.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
            pictureBox1.Visible = false;
            pictureBox2.Visible = true;


        }

        private void guna2PictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btmax_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btmax.Visible = false;
            restoredown.Location = btmax.Location;
            restoredown.Visible = true;
        }

        private void guna2PictureBox5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            restoredown.Visible = false;
            btmax.Visible = true;

        }

        private void restoredown_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
