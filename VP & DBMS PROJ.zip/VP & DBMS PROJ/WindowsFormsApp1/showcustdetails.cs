﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class showcustdetails : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public showcustdetails()
        {
            InitializeComponent();
        }

        private void loaddata()
        {
            con.Open();
            String query1 = "SELECT customer1.name,customer1.fathername,customer1.age,customer1.address,customer1.occupation,customer1.income,customer.accno,customer.bal,customer.cnic FROM customer FULL OUTER JOIN customer1 ON customer.cnic = customer1.cnic ORDER BY customer1.name; ";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
            bunifuCustomDataGrid1.Rows.Clear();
            sda1.Fill(dt1);
           



            con.Close();
            bunifuCustomDataGrid1.DataSource = dt1;
            bunifuCustomDataGrid1.Refresh();
        }
    
        private void showcustdetails_Load(object sender, EventArgs e)
        {
            loaddata();
        }

        public void bunifuCustomDataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            con.Open();
            String query1 = "SELECT customer1.name,customer1.fathername,customer1.age,customer1.address,customer1.occupation,customer1.income,customer.accno,customer.bal,customer.cnic FROM customer FULL OUTER JOIN customer1 ON customer.cnic = customer1.cnic ORDER BY customer1.name; ";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
            sda1.Fill(dt1);




            con.Close();
            bunifuCustomDataGrid1.DataSource = dt1;
        }
    }
}
