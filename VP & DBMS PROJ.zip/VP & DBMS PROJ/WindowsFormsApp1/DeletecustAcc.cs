﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;


namespace WindowsFormsApp1
{
    public partial class DeletecustAcc : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public DeletecustAcc()
        {
            InitializeComponent();
        }

        private void DeletecustAcc_Load(object sender, EventArgs e)
        {
            bunifuThinButton21.BackColor = Color.Transparent;
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == null)
            {
                MessageBox.Show("Enter cnic");
            }

            con.Open();
            
            String query3 = "delete from customer where cnic='" + textBox1.Text + "' ";
            SqlDataAdapter sda3 = new SqlDataAdapter(query3, con);
            DataTable dtb3 = new DataTable();
            sda3.Fill(dtb3);
           


            if ( dtb3.Rows.Count == 0)
            {
                textBox1.Clear();
                MessageBox.Show("Account Deleted");
                
            }
            else
            {
                textBox1.Clear();
                MessageBox.Show("Enter correct Cnic");
            }

            con.Close();

        
    }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
