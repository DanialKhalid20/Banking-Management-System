﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApp1
{
    public partial class Showacc : UserControl
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public Showacc()
        {
            InitializeComponent();
        }
        private void Showacc_Load(object sender, EventArgs e)
        {
           
            con.Open();
            String query1 = "SELECT acc.bankid,acc.password,acc1.name,acc1.fathername,acc1.cnic,acc1.age,acc1.address FROM acc FULL OUTER JOIN acc1 ON acc.cnic = acc1.cnic ORDER BY acc1.name; ";
         
            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
            bunifuCustomDataGrid1.Rows.Clear();
            sda1.Fill(dt1);
            bunifuCustomDataGrid1.DataSource = dt1;


           

            con.Close();
            bunifuCustomDataGrid1.Refresh();


        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            con.Open();
            String query1 = "SELECT acc.bankid,acc.password,acc1.name,acc1.fathername,acc1.cnic,acc1.age,acc1.address FROM acc FULL OUTER JOIN acc1 ON acc.cnic = acc1.cnic ORDER BY acc1.name; ";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
           
            sda1.Fill(dt1);
            bunifuCustomDataGrid1.DataSource = dt1;




            con.Close();

        }
    }
}
