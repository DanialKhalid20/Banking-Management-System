﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class showom : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public showom()
        {
            InitializeComponent();
        }
        public void load(){
            String query1 = "SELECT om.bankid,om.password,om1.name,om1.fathername,om1.cnic,om1.age,om1.address FROM om FULL OUTER JOIN om1 ON om.cnic = om1.cnic ORDER BY om1.name;";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
        //    bunifuCustomDataGrid1.Rows.Clear();

            sda1.Fill(dt1);
            bunifuCustomDataGrid1.DataSource = dt1;
        }
        private void showom_Load(object sender, EventArgs e)
        {
            con.Open();
            load();
          
            con.Close();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            con.Open();
            load();

            con.Close();
        }
    }
}
