﻿
namespace WindowsFormsApp1
{
    partial class acc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(acc));
            this.bunifuThinButton216 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.btmax = new Guna.UI2.WinForms.Guna2PictureBox();
            this.transactions1 = new WindowsFormsApp1.Transactions();
            this.chkbal1 = new WindowsFormsApp1.chkbal();
            this.bunifuThinButton215 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuGradientPanel2 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuThinButton29 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton28 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.restoredown = new Guna.UI2.WinForms.Guna2PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.Manage = new System.Windows.Forms.Label();
            this.showcustdetails1 = new WindowsFormsApp1.showcustdetails();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btmax)).BeginInit();
            this.bunifuGradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.restoredown)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuThinButton216
            // 
            this.bunifuThinButton216.ActiveBorderThickness = 1;
            this.bunifuThinButton216.ActiveCornerRadius = 20;
            this.bunifuThinButton216.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton216.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton216.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton216.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bunifuThinButton216.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton216.BackgroundImage")));
            this.bunifuThinButton216.ButtonText = "Transactions";
            this.bunifuThinButton216.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton216.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton216.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.IdleBorderThickness = 1;
            this.bunifuThinButton216.IdleCornerRadius = 20;
            this.bunifuThinButton216.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton216.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton216.Location = new System.Drawing.Point(4, 55);
            this.bunifuThinButton216.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuThinButton216.Name = "bunifuThinButton216";
            this.bunifuThinButton216.Size = new System.Drawing.Size(152, 46);
            this.bunifuThinButton216.TabIndex = 25;
            this.bunifuThinButton216.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton216.Click += new System.EventHandler(this.bunifuThinButton216_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SeaGreen;
            this.label1.Location = new System.Drawing.Point(629, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 42);
            this.label1.TabIndex = 30;
            this.label1.Text = "Main Menu";
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2PictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox5.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox5.Image")));
            this.guna2PictureBox5.ImageRotate = 0F;
            this.guna2PictureBox5.Location = new System.Drawing.Point(1041, 9);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.Size = new System.Drawing.Size(22, 23);
            this.guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox5.TabIndex = 32;
            this.guna2PictureBox5.TabStop = false;
            this.guna2PictureBox5.Click += new System.EventHandler(this.guna2PictureBox5_Click);
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2PictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox4.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox4.Image")));
            this.guna2PictureBox4.ImageRotate = 0F;
            this.guna2PictureBox4.Location = new System.Drawing.Point(1098, 9);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.Size = new System.Drawing.Size(22, 23);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox4.TabIndex = 31;
            this.guna2PictureBox4.TabStop = false;
            this.guna2PictureBox4.Click += new System.EventHandler(this.guna2PictureBox4_Click);
            // 
            // btmax
            // 
            this.btmax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btmax.BackColor = System.Drawing.Color.Transparent;
            this.btmax.FillColor = System.Drawing.Color.Transparent;
            this.btmax.Image = ((System.Drawing.Image)(resources.GetObject("btmax.Image")));
            this.btmax.ImageRotate = 0F;
            this.btmax.Location = new System.Drawing.Point(1070, 9);
            this.btmax.Name = "btmax";
            this.btmax.Size = new System.Drawing.Size(22, 23);
            this.btmax.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btmax.TabIndex = 33;
            this.btmax.TabStop = false;
            this.btmax.Click += new System.EventHandler(this.btmax_Click);
            // 
            // transactions1
            // 
            this.transactions1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.transactions1.BackColor = System.Drawing.Color.SeaGreen;
            this.transactions1.Location = new System.Drawing.Point(345, 60);
            this.transactions1.Name = "transactions1";
            this.transactions1.Size = new System.Drawing.Size(776, 683);
            this.transactions1.TabIndex = 43;
            this.transactions1.Visible = false;
            // 
            // chkbal1
            // 
            this.chkbal1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkbal1.Location = new System.Drawing.Point(345, 60);
            this.chkbal1.Name = "chkbal1";
            this.chkbal1.Size = new System.Drawing.Size(775, 683);
            this.chkbal1.TabIndex = 38;
            this.chkbal1.Visible = false;
            // 
            // bunifuThinButton215
            // 
            this.bunifuThinButton215.ActiveBorderThickness = 1;
            this.bunifuThinButton215.ActiveCornerRadius = 20;
            this.bunifuThinButton215.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton215.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bunifuThinButton215.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton215.BackgroundImage")));
            this.bunifuThinButton215.ButtonText = "LOGOUT";
            this.bunifuThinButton215.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton215.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton215.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.IdleBorderThickness = 1;
            this.bunifuThinButton215.IdleCornerRadius = 20;
            this.bunifuThinButton215.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton215.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.Location = new System.Drawing.Point(81, 664);
            this.bunifuThinButton215.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton215.Name = "bunifuThinButton215";
            this.bunifuThinButton215.Size = new System.Drawing.Size(193, 56);
            this.bunifuThinButton215.TabIndex = 19;
            this.bunifuThinButton215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton215.Click += new System.EventHandler(this.bunifuThinButton215_Click);
            // 
            // bunifuGradientPanel2
            // 
            this.bunifuGradientPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel2.BackgroundImage")));
            this.bunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton216);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton29);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton28);
            this.bunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.SeaGreen;
            this.bunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.DarkGreen;
            this.bunifuGradientPanel2.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel2.Location = new System.Drawing.Point(12, 162);
            this.bunifuGradientPanel2.Name = "bunifuGradientPanel2";
            this.bunifuGradientPanel2.Quality = 10;
            this.bunifuGradientPanel2.Size = new System.Drawing.Size(317, 110);
            this.bunifuGradientPanel2.TabIndex = 13;
            // 
            // bunifuThinButton29
            // 
            this.bunifuThinButton29.ActiveBorderThickness = 1;
            this.bunifuThinButton29.ActiveCornerRadius = 20;
            this.bunifuThinButton29.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton29.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton29.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton29.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bunifuThinButton29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton29.BackgroundImage")));
            this.bunifuThinButton29.ButtonText = "Show All Accounts";
            this.bunifuThinButton29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton29.Font = new System.Drawing.Font("Microsoft YaHei UI", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton29.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton29.IdleBorderThickness = 1;
            this.bunifuThinButton29.IdleCornerRadius = 20;
            this.bunifuThinButton29.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton29.IdleLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.Location = new System.Drawing.Point(4, 3);
            this.bunifuThinButton29.Name = "bunifuThinButton29";
            this.bunifuThinButton29.Size = new System.Drawing.Size(152, 45);
            this.bunifuThinButton29.TabIndex = 15;
            this.bunifuThinButton29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton29.Click += new System.EventHandler(this.bunifuThinButton29_Click);
            // 
            // bunifuThinButton28
            // 
            this.bunifuThinButton28.ActiveBorderThickness = 1;
            this.bunifuThinButton28.ActiveCornerRadius = 20;
            this.bunifuThinButton28.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton28.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton28.ActiveLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton28.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuThinButton28.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bunifuThinButton28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton28.BackgroundImage")));
            this.bunifuThinButton28.ButtonText = "Check Balance";
            this.bunifuThinButton28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton28.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton28.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton28.IdleBorderThickness = 1;
            this.bunifuThinButton28.IdleCornerRadius = 20;
            this.bunifuThinButton28.IdleFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton28.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton28.IdleLineColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton28.Location = new System.Drawing.Point(161, 4);
            this.bunifuThinButton28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuThinButton28.Name = "bunifuThinButton28";
            this.bunifuThinButton28.Size = new System.Drawing.Size(152, 45);
            this.bunifuThinButton28.TabIndex = 14;
            this.bunifuThinButton28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton28.Click += new System.EventHandler(this.bunifuThinButton28_Click);
            // 
            // restoredown
            // 
            this.restoredown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.restoredown.BackColor = System.Drawing.Color.Transparent;
            this.restoredown.FillColor = System.Drawing.Color.Transparent;
            this.restoredown.Image = ((System.Drawing.Image)(resources.GetObject("restoredown.Image")));
            this.restoredown.ImageRotate = 0F;
            this.restoredown.Location = new System.Drawing.Point(1013, 10);
            this.restoredown.Name = "restoredown";
            this.restoredown.Size = new System.Drawing.Size(22, 23);
            this.restoredown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.restoredown.TabIndex = 34;
            this.restoredown.TabStop = false;
            this.restoredown.Visible = false;
            this.restoredown.Click += new System.EventHandler(this.restoredown_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuThinButton215);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuGradientPanel2);
            this.bunifuGradientPanel1.Controls.Add(this.label4);
            this.bunifuGradientPanel1.Controls.Add(this.label5);
            this.bunifuGradientPanel1.Controls.Add(this.guna2PictureBox3);
            this.bunifuGradientPanel1.Controls.Add(this.Manage);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.SeaGreen;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.LightSeaGreen;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.Green;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Teal;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(345, 743);
            this.bunifuGradientPanel1.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(47, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 27);
            this.label4.TabIndex = 1;
            this.label4.Text = "Main Menu";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(58, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(203, 42);
            this.label5.TabIndex = 2;
            this.label5.Text = "Main Menu";
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.ImageRotate = 0F;
            this.guna2PictureBox3.Location = new System.Drawing.Point(12, 111);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.Size = new System.Drawing.Size(40, 40);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 6;
            this.guna2PictureBox3.TabStop = false;
            // 
            // Manage
            // 
            this.Manage.AutoSize = true;
            this.Manage.BackColor = System.Drawing.Color.Transparent;
            this.Manage.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Manage.Location = new System.Drawing.Point(57, 130);
            this.Manage.Name = "Manage";
            this.Manage.Size = new System.Drawing.Size(159, 21);
            this.Manage.TabIndex = 4;
            this.Manage.Text = "Manage Customers";
            // 
            // showcustdetails1
            // 
            this.showcustdetails1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.showcustdetails1.Location = new System.Drawing.Point(345, 60);
            this.showcustdetails1.Name = "showcustdetails1";
            this.showcustdetails1.Size = new System.Drawing.Size(776, 683);
            this.showcustdetails1.TabIndex = 44;
            this.showcustdetails1.Visible = false;
            // 
            // acc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1121, 743);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guna2PictureBox5);
            this.Controls.Add(this.guna2PictureBox4);
            this.Controls.Add(this.btmax);
            this.Controls.Add(this.restoredown);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.chkbal1);
            this.Controls.Add(this.showcustdetails1);
            this.Controls.Add(this.transactions1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "acc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "acc";
            this.Load += new System.EventHandler(this.acc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btmax)).EndInit();
            this.bunifuGradientPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.restoredown)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton216;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2PictureBox btmax;
        private Transactions transactions1;
        private chkbal chkbal1;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton215;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel2;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton29;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton28;
        private Guna.UI2.WinForms.Guna2PictureBox restoredown;
        private System.Windows.Forms.Timer timer1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private System.Windows.Forms.Label Manage;
        private showcustdetails showcustdetails1;
    }
}