﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Updateom : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public Updateom()
        {
            InitializeComponent();
        }

        private void Updateom_Load(object sender, EventArgs e)
        {
            bunifuThinButton21.BackColor = Color.Transparent;
            bunifuThinButton22.BackColor = Color.Transparent;

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            con.Open();

            String query1 = "SELECT om.bankid,om.password,om1.name,om1.fathername,om1.cnic,om1.age,om1.address FROM om  FULL OUTER JOIN om1 ON om.cnic = om1.cnic where om.cnic='"+textBox1.Text+"'; ";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.Connection = con;

            SqlDataReader sd = cmd1.ExecuteReader();

            while (sd.Read())
            {
                textBox7.Text = sd.GetValue(1).ToString();
                textBox4.Text = sd.GetValue(2).ToString();
                textBox3.Text = sd.GetValue(6).ToString();
                textBox5.Text = sd.GetValue(3).ToString();
                textBox2.Text = sd.GetValue(4).ToString();
                textBox8.Text = sd.GetValue(0).ToString();
                textBox9.Text = sd.GetValue(5).ToString();
            }

            con.Close();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            con.Open();

            String query1 = "update om set om.bankid='" + int.Parse(textBox8.Text) + "',om.cnic='" + textBox2.Text + "',om.password='" + textBox7.Text + "'";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.ExecuteNonQuery();

            string query2 = "update om1 set om1.name='" + textBox4.Text + "',om1.fathername='" + textBox5.Text + "',om1.cnic='" + textBox2.Text + "',om1.address='" + textBox3.Text + "',om1.age='" + textBox1.Text + "'  ";

            SqlCommand cmd2 = new SqlCommand(query2, con);

            
            cmd2.ExecuteNonQuery();

            con.Close();
        }
    }
}
