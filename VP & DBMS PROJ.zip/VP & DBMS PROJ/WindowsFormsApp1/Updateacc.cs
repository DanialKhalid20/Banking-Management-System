﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class Updateacc : UserControl
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public Updateacc()
        {
            InitializeComponent();
        }

        private void Updateacc_Load(object sender, EventArgs e)
        {
            bunifuThinButton21.BackColor = Color.Transparent;
            bunifuThinButton22.BackColor = Color.Transparent;

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            con.Open();

            String query1 = "SELECT acc.bankid,acc.password,acc1.name,acc1.fathername,acc1.cnic,acc1.age,acc1.address FROM acc  FULL OUTER JOIN acc1 ON acc.cnic = acc1.cnic; ";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.Connection = con;
            
            SqlDataReader sd = cmd1.ExecuteReader();

            while (sd.Read())
            {
                textBox7.Text = sd.GetValue(1).ToString();
                textBox4.Text = sd.GetValue(2).ToString();
                textBox3.Text = sd.GetValue(6).ToString();
                textBox5.Text = sd.GetValue(3).ToString();
                textBox2.Text = sd.GetValue(4).ToString();
                textBox8.Text = sd.GetValue(0).ToString();
                textBox9.Text = sd.GetValue(5).ToString();



            }





            con.Close();


        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {

            con.Open();

            String query1 ="update acc set acc.bankid='"+int.Parse(textBox8.Text)+"',acc.cnic='"+textBox2.Text+ "',acc.password='"+textBox7.Text+"'";

            SqlCommand cmd1 = new SqlCommand(query1, con);

            string query2 = "update acc1 set acc1.name='" + textBox4.Text + "',acc1.fathername='" + textBox5.Text + "',acc1.cnic='" + textBox2.Text + "',acc1.address='" + textBox3.Text + "',acc1.age='" + textBox1.Text + "'  ";

            SqlCommand cmd2 = new SqlCommand(query2, con);

            cmd1.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            
            con.Close();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

