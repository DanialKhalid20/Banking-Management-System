﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class acc : Form
    {
        public acc()
        {
            InitializeComponent();
        }

        private void acc_Load(object sender, EventArgs e)
        {
            bunifuThinButton28.BackColor = Color.Transparent;
            bunifuThinButton29.BackColor = Color.Transparent;
            bunifuThinButton215.BackColor = Color.Transparent;
            bunifuThinButton216.BackColor = Color.Transparent;

        }

        private void bunifuThinButton29_Click(object sender, EventArgs e)
        {
            showcustdetails1.Visible = true;
            showcustdetails1.BringToFront();
        }

        private void guna2PictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2PictureBox5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btmax_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btmax.Visible = false;
            restoredown.Location = btmax.Location;
            restoredown.Visible = true;
        }

        private void restoredown_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            restoredown.Visible = false;
            btmax.Visible = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label5.Text = DateTime.Now.ToLongTimeString();
            label4.Text = DateTime.Now.ToLongDateString();
        }

        private void bunifuThinButton28_Click(object sender, EventArgs e)
        {
            chkbal1.Visible = true;
            chkbal1.BringToFront();
        }

        private void bunifuThinButton216_Click(object sender, EventArgs e)
        {
            transactions1.Visible = true;
            transactions1.BringToFront();
        }

        private void bunifuThinButton215_Click(object sender, EventArgs e)
        {
            this.Hide();
            signin s = new signin();
            s.Show();
        }
    }
}
