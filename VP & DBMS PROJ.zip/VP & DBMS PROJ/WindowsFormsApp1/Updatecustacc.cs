﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Updatecustacc : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-J8250CD;Initial Catalog=projdb;Integrated Security=True");

        public Updatecustacc()
        {
            InitializeComponent();
        }

        private void Updatecustacc_Load(object sender, EventArgs e)
        {
            bunifuThinButton21.BackColor = Color.Transparent;
            bunifuThinButton22.BackColor = Color.Transparent;

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            con.Open();

            String query1 = "SELECT customer.accno,customer.cnic,customer1.name,customer1.fathername,customer1.age,customer1.address,customer1.occupation,customer1.income FROM customer  FULL OUTER JOIN customer1 ON customer.cnic = customer1.cnic where customer.cnic='" + textBox1.Text + "'; ";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.Connection = con;

            SqlDataReader sd = cmd1.ExecuteReader();

            while (sd.Read())
            {
                textBox7.Text = sd.GetValue(0).ToString();
                textBox4.Text = sd.GetValue(2).ToString();
                textBox3.Text = sd.GetValue(5).ToString();
                textBox5.Text = sd.GetValue(3).ToString();
                textBox2.Text = sd.GetValue(1).ToString();
                textBox9.Text = sd.GetValue(4).ToString();
                textBox6.Text = sd.GetValue(6).ToString();
                textBox8.Text = sd.GetValue(7).ToString();

            }

            con.Close();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            con.Open();

            String query1 = "update customer set customer.accno='" +textBox7.Text + "',customer.cnic='" + textBox2.Text + "'";

            SqlCommand cmd1 = new SqlCommand(query1, con);

            string query2 = "update customer1 set customer1.name='" + textBox4.Text + "',customer1.fathername='" + textBox5.Text + "',customer1.cnic='" + textBox2.Text + "',customer1.address='" + textBox3.Text + "',customer1.age='" + textBox9.Text + "',customer1.occupation='" + textBox6.Text + "',customer1.income='" + textBox8.Text + "'  ";

            SqlCommand cmd2 = new SqlCommand(query2, con);

            cmd1.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();

            con.Close();
        }
    }
}
