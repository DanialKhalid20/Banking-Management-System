﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Manage_om : Form
    {
        public Manage_om()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            Add_om a = new Add_om();
            this.Hide();
            a.Show();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            Dlt_om d = new Dlt_om();
            this.Hide();
            d.Show();
        }
    }
}
