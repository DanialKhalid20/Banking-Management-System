﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp1
{
    public partial class splash : Form
    {
        public splash()
        {

            InitializeComponent();
            
        }
        private void label1_Click(object sender, EventArgs e)
        {
           
        }
        private void splash_Load(object sender, EventArgs e)
        {
           
        }
        public void startform()
        {
            Application.Run(new splash());
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;

    
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Increment(3);
            if (progressBar1.Value == 100)
            {
                timer1.Stop();
            }
        }

        

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
